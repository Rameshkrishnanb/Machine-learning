#!/usr/bin/env python
from sklearn.datasets import load_boston
from sklearn.decomposition import PCA
from sklearn.metrics import mean_squared_error
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVR
import numpy as np
import pandas as pd
bos=load_boston()
X=bos.data
y=bos.target
pca=PCA(3)
regression=SVR()
regression.fit(X,y)
p=regression.predict(X)
f=mean_squared_error(y,p)
print('RMSE:',(f**0.5))
