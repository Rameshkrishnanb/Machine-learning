#!/usr/bin/env python
from sklearn.datasets import load_diabetes
from sklearn.decomposition import PCA
from sklearn.metrics import mean_squared_error
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVR
import numpy as np
import pandas as pd
dia=load_diabetes()
X=dia.data
y=dia.target
pca=PCA(3)
regression=SVR()
regression.fit(X,y)
p=regression.predict(X)
f=mean_squared_error(y,p)
print('RMSE:',(f**0.5))
