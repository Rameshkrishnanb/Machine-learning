#!/usr/bin/env python
from sklearn.datasets import load_breast_cancer
from sklearn.decomposition import PCA
from sklearn.metrics import confusion_matrix,accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
cancer=load_breast_cancer()
pca=PCA(2)
classifier=SVC()
X=cancer.data
y=cancer.target
scaler=StandardScaler()
X=scaler.fit_transform(X)
X=pca.fit_transform(X)
#print(X)
X_train,X_test,y_train,y_test=train_test_split(X,y)
classifier.fit(X_train,y_train)
p=classifier.predict(X_test)
print(accuracy_score(y_test,p))
print(confusion_matrix(y_test,p))

#....................pipelining................................
pipe=Pipeline([('pca',PCA()),('svc',SVC())])
pipe.fit(X_train,y_train)
p=pipe.predict(X_test)
print("pipeline")
print(accuracy_score(y_test,p))
print(confusion_matrix(y_test,p))




