#!/usr/bin/env python
from sklearn.datasets import load_breast_cancer
from sklearn.metrics import accuracy_score,confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.svm import SVC
can=load_breast_cancer()
X=can.data
y=can.target
lda=LinearDiscriminantAnalysis(n_components=2)
X=lda.fit_transform(X,y)
#svc=SVC()
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2)
lda.fit(X_train,y_train)
p=lda.predict(X_test)
print 'Confusion Matrix\n',(confusion_matrix(y_test,p))
print'Accuracy Score:',(accuracy_score(y_test,p))
