#!/usr/bin/env python
from sklearn import preprocessing
import pandas as pd
le=preprocessing.LabelEncoder()
dataset=pd.read_csv("banking.csv")
dataset=dataset.as_matrix()
dataset[:,1]=le.fit_transform(dataset[:,1])
a=dataset[:,1]
print a



