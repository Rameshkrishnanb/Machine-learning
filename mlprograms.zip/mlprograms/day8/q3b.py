#!/usr/bin/env python
import pandas as pd
from sklearn import preprocessing
le=preprocessing.LabelEncoder()
dataset=pd.read_csv("banking.csv")
dataset=dataset.as_matrix()
dataset[:,1]=le.fit_transform(dataset[:,1])
oe=preprocessing.OneHotEncoder()
dt=oe.fit_transform(dataset[:,(1,-1)]).toarray()
print(dt)
