#!/usr/bin/env python
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix
dataset=pd.read_csv("banking.csv")
dataset=dataset.as_matrix()
X=dataset[:,0:20]
y=dataset[:,-1]
rf=RandomForestClassifier()
rf.fit(X,y)
p=rf.predict(X)
print(confusion_matrix(p,y))
