#!/usr/bin/env python
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix
dat=pd.read_csv("pimaindians.csv")
dat=dat.as_matrix()
X=dat[:,0:8]
y=dat[:,-1]
rf=RandomForestClassifier()
rf.fit(X,y)
p=rf.predict(X)
print(confusion_matrix(p,y))
