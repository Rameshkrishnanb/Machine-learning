# Question 1

library(caret)
library(e1071)

dataset<-iris
dim(iris)
spe<-iris$Species

trainset<-dataset
fit.knn <- train(Species~.,data=dataset,method="knn",metric="Accuracy")
p <-predict(fit.knn,iris)
p 



#Question 2

dataset<-iris
dataset

v<-createDataPartition(iris$Species,p=0.80,list = FALSE)
trainset<-dataset[v,]
dim(trainset)
testset<-dataset[-v,]
dim(testset)
fit.knn <- train(Species~.,data=trainset,method="knn",metric="Accuracy")
pre<-predict(fit.knn,testset)
con<-confusionMatrix(pre,testset$Species)
con

#Question 3

dataset<-read.table("/home/ai18/Downloads/ecoli.data")
head(dataset)
dataset$V9
fit.knn<-train(V9~.,data = dataset,method="knn",metric=metric)
predictions<-predict(fit.knn,dataset)
cmat<-confusionMatrix(predictions,dataset$V9)

#Question4
dataset<-read.csv(file.choose(),header = TRUE)
metric="Accuracy"
fit.lda<-train(CentralHeating~.,data = dataset,method="knn",metric=metric)

predictions<-predict(fit.lda,dataset)
cmat<-confusionMatrix(predictions,dataset$CentralHeating)





