#!/usr/bin/env python
from sklearn.cluster import KMeans
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from mpl_toolkits import mplot3d
import numpy

d=pd.read_csv("/home/ai6/ML/day6/titanic.csv")
feature_cols1 = ['PassengerId','Survived','Age']
da=d[feature_cols1]
da=da.dropna(subset=feature_cols1)
X=da.as_matrix()
fig=plt.figure()
ax=plt.axes(projection='3d')
kmeans=KMeans(n_clusters=2)
kmeans.fit(X)
y_means=kmeans.predict(X)
ax.scatter3D(X[:,0],X[:,1],X[:,2],c=y_means,s=50)
plt.show()

x=X[:,[0,2]]
print(x)
y=X[:,[1]]
print(y)
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2)
l=LogisticRegression()
l.fit(x_train,y_train)
p=l.predict(x_test)
deadoralive=l.predict(x_train[[9]])
print(y_train[[9]]);
print(deadoralive)

