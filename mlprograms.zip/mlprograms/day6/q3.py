#!/usr/bin/env python
from sklearn.cluster import KMeans
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

d=pd.read_csv("/home/ai6/ML/day6/ex3.txt")
data=d.as_matrix()
X=data
kmeans=KMeans(n_clusters=2)
kmeans.fit(X)
y_means=kmeans.predict(X)
plt.scatter(X[:,0],X[:,1],c=y_means,s=50,cmap='viridis')
plt.show()

x=X[:]
y=X[:,-1]
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2)
l=LogisticRegression()
l.fit(x_train,y_train)
p=l.predict(x_test)
admission=l.predict(x_train[[10]])
print(x_train[[10]])
print(admission)
print(X)

