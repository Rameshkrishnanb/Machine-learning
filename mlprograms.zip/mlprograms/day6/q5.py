#!/usr/bin/env python
from sklearn.cluster import KMeans
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

d=pd.read_csv("/home/ai6/ML/day6/mining.csv")
print(d)
feature_cols1 = ['Facies','ILD_log10']
da=d[feature_cols1]
print(da)
X=da.as_matrix()
kmeans=KMeans(n_clusters=9)
kmeans.fit(X)
y_means=kmeans.predict(X)
plt.scatter(X[:,0],X[:,1],c=y_means,s=50)
plt.show()
#prediction
x=X[:,[1]]
y=X[:,[0]]
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2)
l=KNeighborsClassifier(n_neighbors=3)
l.fit(x_train,y_train)
p=l.predict(x_test)
facies=l.predict(x_train[[9]])
print(y_train[[9]]);
print(facies)

