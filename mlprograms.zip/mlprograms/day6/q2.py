#!/usr/bin/env python
from sklearn.cluster import KMeans
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from mpl_toolkits import mplot3d

d=pd.read_csv("/home/ai6/ML/day6/ex2.txt")
data=d.as_matrix()
X=data
fig=plt.figure()
ax=plt.axes(projection='3d')
kmeans=KMeans(n_clusters=3)
kmeans.fit(X)
y_means=kmeans.predict(X)
ax.scatter3D(X[:,0]*0.001,X[:,1],X[:,2]*.00001,c=y_means,s=50,cmap='viridis')
plt.show()

x=X[:,0:2]
y=X[:,-1]
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2)
l=LinearRegression()
l.fit(x_train,y_train)
p=l.predict(x_test)
sales=l.predict(x_train[[9]])
print(x_train[[9]])
print(sales)
print(X)

