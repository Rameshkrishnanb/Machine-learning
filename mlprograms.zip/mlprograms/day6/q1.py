#!/usr/bin/env python
from sklearn.cluster import KMeans
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

d=pd.read_csv("/home/ai6/ML/day6/ex1.txt")
data=d.as_matrix()
X=data
kmeans=KMeans(n_clusters=3)
kmeans.fit(X)
y_means=kmeans.predict(X)
plt.scatter(X[:,0],X[:,1],c=y_means,s=50,cmap='viridis')
plt.show()

x=X[:,-1]
x=x.reshape(-1,1)
y=X[:,0]
y=y.reshape(-1,1)
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2)
l=LinearRegression()
l.fit(x_train,y_train)
p=l.predict(x_test)
sales=l.predict(x_train[[9]])
print(x_train[[9]])
print(sales)
print(X)

