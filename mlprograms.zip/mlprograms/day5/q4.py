#!/usr/bin/env python
import pandas as pd
from sklearn.linear_model import LinearRegression

from sklearn.cross_validation import train_test_split
from sklearn import metrics
import numpy as np
data=pd.read_csv("Advertising.csv",index_col=0)
data=data.as_matrix()
X=data[:,0:2]
y=data[:,-1]
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.4,random_state=4)
linreg1=LinearRegression()
linreg1.fit(X_train,y_train)
print(linreg1.coef_)
print(linreg1.intercept_)
y_pred=linreg1.predict(X_test)
print("Absolute Error")
print("Mean squred error")
print("Root mean squared error")
print(metrics.mean_absolute_error(y_test,y_pred))
print(metrics.mean_squared_error(y_test,y_pred))
print(np.sqrt(metrics.mean_squared_error(y_test,y_pred)))
