#!/usr/bin/env python 
import pandas as pd
from mpl_toolkits import mplot3d
import matplotlib.pyplot as plt
from sklearn.datasets.samples_generator import make_blobs
data=pd.read_csv('/home/ai6/Desktop/common/ML/Day5/sample.csv',delimiter=',')
import pandas as pd
X=data.as_matrix()
fig=plt.figure()
ax=plt.axes(projection='3d')
print(X)
from sklearn.cluster import KMeans
kmeans=KMeans(n_clusters=3)
kmeans.fit(X)
y_means=kmeans.predict(X)
print(y_means)
ax.scatter3D(X[:,0],X[:,1],X[:,2],y_means,s=50,cmap='viridis')
centers=kmeans.cluster_centers_
ax.scatter3D(centers[:,0],centers[:,1],centers[:,2],s=200,c='red')
plt.show()
