#!/usr/bin/env python
from sklearn.datasets import load_diabetes
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import Ridge
import numpy as np
alphas=np.array([1,0.1,0.001,.0001])
model=Ridge()
grid=GridSearchCV(estimator=model,param_grid=dict(alpha=alphas))
diabetes=load_diabetes()
X=diabetes.data
y=diabetes.target
grid.fit(X,y)
print(grid)
print(grid.best_score_)
print(grid.best_estimator_.alpha)

