#!/usr/bin/env python
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score,confusion_matrix
from sklearn.model_selection import  train_test_split
from sklearn.model_selection import cross_val_score
import  pandas as pd
import matplotlib.pyplot as plt
data=pd.read_csv("city.csv",index_col=0)
print(data.head())
data = data.as_matrix()
X = data[:,0:5]
y = data[:,-1] 
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2)
k_range=list(range(1,16))
score=[]
for k in k_range:
 knn=KNeighborsClassifier(n_neighbors=k)
 scores=cross_val_score(knn,X,y,cv=10,scoring="accuracy")
 i= knn.fit(X_train,y_train)
 predictions=knn.predict(X_test)
 t=accuracy_score(y_test,predictions)
 score.append(t)
 m=confusion_matrix(y_test,predictions)
 print (t)
 print ' CONFUSION MATRIX',m
 print scores
plt.plot(k_range,score)
plt.xlabel('  K Values ')
plt.ylabel('Accuracy Score')
plt.show()
