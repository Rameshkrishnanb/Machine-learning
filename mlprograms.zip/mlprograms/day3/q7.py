#!/usr/bin/env python
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.cross_validation import train_test_split
from sklearn import metrics
data=pd.read_csv("/home/ai6/ML/x01.csv")
data=data.as_matrix()
X=data[:,]
y=data[:,-1]
X_train,Xtest,y_train,y_test=train_test_split(X,y,test_size=0.2)
model=LinearRegression()
model.fit(X_train,y_train)
p=model.predict(X_test)
print(mean_squared_error(y_test,p))
plt_scatter(y_test,p)
plt.show()
