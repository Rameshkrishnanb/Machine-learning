#!/usr/bin/env python
import pandas as pd
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score,confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
import matplotlib.pyplot as plt
dataset=pd.read_csv('Immunotherapy.csv')
dataset=dataset.as_matrix()
X=dataset[:,0:7]
y=dataset[:,-1]
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2)
k_range=list(range(1,16))
score=[]
for k in k_range:
	knn=KNeighborsClassifier(n_neighbors=k)
	scores=cross_val_score(knn,X,y,cv=20,scoring='accuracy')
	print(scores)
	knn.fit(X_train,y_train)
	predictions=knn.predict(X_test)
	a=accuracy_score(y_test,predictions)
	score.append(a)
        con=confusion_matrix(y_test,predictions)
	print 'Confusion Matrix: ',con
plt.plot(k_range,score)
plt.xlabel('values of k')
plt.ylabel('Accuracy scores')
plt.show()



