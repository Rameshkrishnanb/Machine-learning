#!/usr/bin/env python
import pandas as pd
import numpy as  np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler,MinMaxScaler
from sklearn.metrics import confusion_matrix,accuracy_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics

dataframe=pd.read_csv("Immunotherapy.csv")
array=dataframe.as_matrix()
X=array[:,0:7]
y=array[:,-1]

X_test,X_train,y_test,y_train=train_test_split(X,y,test_size=0.2)
knn=KNeighborsClassifier(n_neighbors=2)
knn.fit(X_train,y_train)
p=knn.predict(X_test)
print "Accuracy score:",(accuracy_score(y_test,p))
print "Confision Matrix:\n",(confusion_matrix(y_test,p))

#.............Standard Scaler

scaler=StandardScaler()
X1=scaler.fit_transform(X)
X_test,X_train,y_test,y_train=train_test_split(X1,y,test_size=0.2)
knn.fit(X_train,y_train)
p=knn.predict(X_test)
print"Accuracy Score:",(accuracy_score(y_test,p))
print "Confision Matrix:\n",(confusion_matrix(y_test,p))

#..............MinMaxScaler
scaler=MinMaxScaler()
X=scaler.fit_transform(X)
X_test,X_train,y_test,y_train=train_test_split(X,y,test_size=0.2)
knn.fit(X_train,y_train)
p=knn.predict(X_test)
print"Accuracy Score:",(accuracy_score(y_test,p))
print "Confision Matrix:\n",(confusion_matrix(y_test,p))

