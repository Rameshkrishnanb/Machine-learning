#!/usr/bin/env python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler,MinMaxScaler
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsRegressor

dataframe=pd.read_csv("bikeshare.csv")
arrar=dataframe.as_matrix()
X=arrar[:,1:11]
y=arrar[:,-1]

X_test,X_train,y_test,y_train=train_test_split(X,y,test_size=0.2)
knn=KNeighborsRegressor(3)
knn.fit(X_train,y_train)
p=knn.predict(X_test)
print(metrics.mean_squared_error(y_test,p))
plt.scatter(y_test,p,color='red')
plt.xlabel("actual values")
plt.ylabel("predicted vaues")
plt.show()
#.....standard scaler
scaler=StandardScaler()
X1=scaler.fit_transform(X)
X_test,X_train,y_test,y_train=train_test_split(X1,y,test_size=0.2)
knn.fit(X_train,y_train)
p=knn.predict(X_test)
print(metrics.mean_squared_error(y_test,p))



#........MinMax scaler
scaler=MinMaxScaler()
X=scaler.fit_transform(X)
X_test,X_train,y_test,y_train=train_test_split(X,y,test_size=0.2)
knn.fit(X_train,y_train)
p=knn.predict(X_test)
print(metrics.mean_squared_error(y_test,p))



