#!/usr/bin/env python
from sklearn.model_selection import cross_val_score,train_test_split,KFold
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder,StandardScaler,MinMaxScaler
import pandas as pd
import matplotlib.pyplot as plt
data=pd.read_csv("banking.csv")
le=LabelEncoder()
for col in data.columns:
 if data[col].dtypes=='object':
   le.fit(data[col].values)
   data[col]=le.transform(data[col])

data=data.as_matrix()
X=data[:,0:20]
y=data[:,-1]
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2)
knn=KNeighborsClassifier(2)
knn.fit(X_train,y_train)
pknn=knn.predict(X_test)

kfold=KFold(10,random_state=7)
models=[]
models.append(("KNN",KNeighborsClassifier()))
models.append(("LG",LogisticRegression()))
models.append(("RF",RandomForestClassifier()))
models.append(("CAET",DecisionTreeClassifier()))
result=[]
names=[]
for name,model in models:
	v=cross_val_score(model,X,y,cv=kfold)
	result.append(v)
	names.append(name)
	print(name)
	print(v)
fig=plt.figure()
fig.suptitle("Performance Comparison")
ax=fig.add_subplot(111)
plt.boxplot(result)
ax.set_xticklabels(names)
plt.show()



 
