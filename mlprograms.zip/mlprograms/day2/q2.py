#!/usr/bin/env python
from sklearn.datasets import load_iris
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import  train_test_split
from sklearn.metrics  import accuracy_score,confusion_matrix

iris=load_iris()
X=iris.data
y=iris.target
print(iris.data)
print (iris.feature_names)
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2)
print(X_train.shape)
print(y_train.shape)
print(X_test.shape)
print(y_test.shape)
knn=KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train,y_train)
predictions=knn.predict(X_test)
print(predictions)
print(accuracy_score(y_test,predictions))
print(confusion_matrix(y_test,predictions))
print(knn.predict([[3,5,4,2]]))
print(knn.predict(X))
print(y)


