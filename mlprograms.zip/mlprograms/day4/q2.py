#!/usr/bin/env python
from sklearn.datasets import load_iris
from sklearn.datasets.samples_generator import make_blobs
import matplotlib.pyplot as plt
iris=load_iris()
X=iris.data
X=X[:,0:2]
y=iris.target
from sklearn.cluster import KMeans
kmeans= KMeans(n_clusters=4)
kmeans.fit(X)
y_means=kmeans.predict(X)
plt.scatter(X[:,0],X[:,1],c=y_means,s=50,cmap='viridis')
centers=kmeans.cluster_centers_
plt.scatter(centers[:,0],centers[:,1],s=100,c='red')
plt.show()
