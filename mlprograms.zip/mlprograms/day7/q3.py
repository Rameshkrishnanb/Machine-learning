#!/usr/bin/env python
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
data=pd.read_csv("binary.txt",delimiter='\t')
data=data.as_matrix()
print(data.shape)
X=data[:,0:2]
y=data[:,-1]
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2)
model=LogisticRegression()
model.fit(X_train,y_train)
predictions=model.predict(X_test)
#plt.scatter(y_test,predictions)
#plt.show()
from sklearn.metrics import classification_report
from sklearn import metrics
import numpy as np
print('Mean squared error is %d'%(metrics.mean_squared_error(y_test,predictions)))
print('Root means squared error is %f'%(np.sqrt(metrics.mean_squared_error(y_test,predictions))))
print(classification_report(y_test,predictions))

