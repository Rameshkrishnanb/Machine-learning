#!/usr/bin/env python
from sklearn.datasets import load_boston
from sklearn.metrics import mean_squared_error
from sklearn.tree import DecisionTreeRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
Boston=load_boston()
X=Boston.data
y=Boston.target

X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2)

tree=DecisionTreeRegressor()
tree.fit(X_train,y_train)
ptree=tree.predict(X_test)

knn=KNeighborsRegressor()
knn.fit(X_train,y_train)
pknn=knn.predict(X_test)

print'tree mean square',mean_squared_error(y_test,ptree)**0.5
print'KNN',mean_squared_error(y_test,pknn)**0.5

plt.scatter(y_test,ptree,c='red')
plt.xlabel("Test value")
plt.ylabel("Predicted value")
plt.title("Decision tree regression")
plt.show()
