#!/usr/bin/env python
from sklearn.datasets import load_iris
from sklearn.model_selection import cross_val_score
from sklearn.metrics import accuracy_score,confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
iris=load_iris()
X=iris.data
y=iris.target
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2)


tree=DecisionTreeClassifier()
tree.fit(X_train,y_train)
p=tree.predict(X_test)

print'Cross value',cross_val_score(tree,X,y,cv=20,scoring='accuracy')
print'Accuracy Score',accuracy_score(y_test,p)
print'Confusson Matrix',confusion_matrix(y_test,p)

